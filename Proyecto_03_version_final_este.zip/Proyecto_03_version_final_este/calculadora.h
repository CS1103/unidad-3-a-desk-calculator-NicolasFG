
#ifndef PROYECTO_03_VERSION_FINAL_ESTE_CALCULADORA_H
#define PROYECTO_03_VERSION_FINAL_ESTE_CALCULADORA_H

#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <cctype>
#include <cmath>

using namespace std;
/*
 * Tipo enumeracion que controla los TOKEN o entradas utilizadas por el analizador,
 * tener definidas las operaciones u opciones en este tipo, facilita la programacion
 * de la calculadora.
 */
enum Token_value
{
    NAME,			NUMBER,			END,			FUNC = '$',
    ADD = '+', 		SUB = '-', 		MUL = '*', 		DIV = '/',
    PRINT = ';', 	ASSIGN = '=',	LP = '(',		RP = ')',
    EXPO = '^',		LCB = '{',		RCB = '}',		COMMA = ','
};


/*
 * Se crea la variable de enumeracion y se inicializa en PRINT, garantizando la ejecucion
 */
Token_value curr_tok = PRINT;


/*
 * Funcion de entradas (input), su encabezado, la definicion de la misma es posterior.
 */
Token_value get_token();



/*
 * Variables globales que se utilizan para obtener el valor de un token o entrada
 */
double number_value;
string string_value;




/*
 * Variable que contiene el error y funcion que maneja ese error (Error handling (manejo))
  */
int no_of_errors;
double error(const string& s);




/*
 * Tabla de símbolos utilizada para almacenar variables y constantes predefinidas
 */
map<string, double> globals;


/*
 * Estructura para Funciones definidas por el usuario y el mapa para asociar el
 * nombre de la función a la función real.
 * Para definir una función, debe escribir, por ejemplo: "$ func (x) {x = x + 2;}"
 * y la llamada seria: "$ func (20)" e indicaria el resultado.
 * Puede guardar el valor de la función en una variable o combinar una llamada de
 * función con otras expresiones.
 */
struct Function
{
    Function() : arg_count(0) {}
    Function(const string& nm) : name(nm), arg_count(0) {}

    string name;			       // Nombre de la funcion
    size_t arg_count;		       // Numero de argumentos que acepta la funcion
    map<string, double> arg_table; // Diccionario de argumentos de pareja nombre/valor
    string body;			       // Definicion
};

//Mapa o Tabla de símbolos para funciones pre / definidas por el usuario:
map<string, Function> func_table;


/*
 * Devuelve si existe una función con el nombre dado en func_table
 */
bool funcExists(const string& name);


/*
 * Funciones definidas por el usuario del parser (analizador) (usa descenso recursivo)
 */
double expr(bool); // Para la suma y resta
double term(bool); // Para multiplicacion y division
double prim(bool); // Para primarias, como nombre o numero


/*
 * Puntero a la secuencia de entrada de la que recibimos nuestra entrada, es la cadena
 * en base a la cual se realiza la operacion.
 */
istream* input;


/*
 * Mapa de simbolos que albergara el mapa global
 */
map<string, double>* table;


/*
 * Función de manejo (handling) de errores:
 */
double error(const string& s)
{
    ++no_of_errors;
    cerr << "Error: \"" << s << "\"" << endl;
    return 1;
}

/*
 * Funcion de las entradas a la calculadora
 */
Token_value get_token()
{
    char ch = 0;

    // Se lee la entrada
    do
    {	// Se omiten los espacios en blanco, excepto '\n'
        if(!input->get(ch))
            return curr_tok = END;
    } while(ch != '\n' && isspace(ch));

    // Se compara la entrada
    switch(ch)
    {
        case 0:
            return curr_tok = END; // Orden de finalizar
        case ';':
        case '\n':
            return curr_tok = PRINT; // Orden de continuar
        case '+':
        case '-':
        case '*':
        case '/':
        case '(':
        case ')':
        case '=':
        case ',':
        case '^':
        case '}':
            return curr_tok = Token_value(ch); // Se retorna el valor

            // Elementos numericos de la calculadora
        case '0': case '1': case '2': case '3': case '4':
        case '5': case '6': case '7': case '8': case '9':
        case '.':
            input->putback(ch);       // Se agrega el caracter al string que sera objeto calculo
            *input >> number_value;   // Su contenido se asigna a la variable global: number_value
            return curr_tok = NUMBER; // Indicamos que es un numero
        case '$': // Como se explico en la estructura, se define la funcion o la llamada
        {
            if(!input->get(ch) || !isalpha(ch)) // Caso de la opcion de salir de la calculadora
                return curr_tok = END;
            else
                string_value = ch; // Asignamos el caracter

            // Se diferencia en la entrada entre digitos y letras
            while(input->get(ch) && (isalnum(ch) || ch == '_'))
            {
                string_value += ch; // Se anexa el elemento
            }
            input->putback(ch); // Asignamos el elemento al final del input
            return curr_tok = FUNC; // Retornamos el toquen de tipo FUNC
        }
        case '{':
        {
            string_value.clear(); // Limpiamos el string de valores
            while(input->get(ch) && ch != '}') // Mientras no se reciba la llave de cierre, asignamos elementos
            {
                string_value += ch;
            }
            return curr_tok = LCB;
        }
        default: // Nombre o se produjo un error
            if(isalpha(ch)) // Si es alfabetico
            {
                string_value = ch;
                while(input->get(ch) && (isalnum(ch) || ch == '_'))
                    string_value.push_back(ch);  // Asignamos al final del string
                input->putback(ch);
                return curr_tok = NAME; // Retornamos el nombre
            }
            error("bad token"); // Se produjo un error
            return curr_tok = PRINT; // Orden de continuar
    }
}

/*
 * Funcion definida para la suma y la resta:
 */
double expr(bool get)
{
    double left = term(get);

    for(;;) // Ciclo infinito, se suponen infinidad de elementos en una expresion de calculo
    {
        switch(curr_tok)
        {
            case ADD: // Opcion de suma
            {
                left += term(true);
                break;
            }
            case SUB: // Opcion de resta
            {
                left -= term(true);
                break;
            }
            default:
                return left; // Retornaos el elemento
        }
    }
}


/*
 * Manejo de la multiplicacion, division y exponencial:
 */
double term(bool get)
{
    double left = prim(get);

    for(;;) // Ciclo infinito, se suponen infinidad de elementos en una expresion de calculo
    {
        switch(curr_tok)
        {
            case MUL: // Multiplicacion
            {
                left *= prim(true);
                break;
            }
            case DIV: // Division
            {
                if(double d = prim(true))
                {
                    left /= d;
                    break;
                }
                return error("divide by zero");
            }
            case EXPO: // Exponencial
            {
                left = pow(left, prim(true));
                break;
            }
            default:
                return left;
        }
    }
}


/*
 * Manejo primarias, como nombre o número.
 * La función prim () usa para obtener valores para las variables, un puntero a un mapa,
 * y para las expresiones regulares, se establece en la tabla de símbolos principal.
 * Cuando se evalúa una función se señalar el mapa de argumentos para esa función y copiar
 * las variables globales en ella, para que puedan usarse en la llamada a la función.
 */
double prim(bool get)
{
    if(get) get_token(); // Se lee un token

    switch(curr_tok) // CASE de la varible de enumeracion: curr_tok
    {
        case NUMBER: // Notese la recursividad
        {
            double v = number_value;
            get_token();
            return v;
        }
        case NAME:
        {
            double& v = table->operator[](string_value);
            if(get_token() == ASSIGN)
                v = expr(true);
            return v;
        }
        case FUNC:
        {
            if(funcExists(string_value))	// Verificamos si la funcion existe
            {
                Function f(func_table[string_value]); // Se llama la funcion

                if(get_token() == LP)
                {
                    map<string, double>::iterator it = f.arg_table.begin();
                    while(get_token() != RP && curr_tok != END)
                    {
                        if(it == f.arg_table.end()) continue;
                        switch(curr_tok)
                        {
                            case NAME:
                                if(table->count(string_value) > 0)
                                {
                                    it->second = table->operator[](string_value);
                                    ++it;
                                    break;
                                }
                                else
                                    return error("argumento de funcion desconocida");
                            case NUMBER:
                                it->second = number_value;
                                ++it;
                                break;
                            case COMMA:
                                continue;
                            default:
                                return error("argumento de funcion no valida");
                        }
                    }

                    /*
                     * Comprueba si el número de argumentos es el mismo para la llamada a la función
                     * y la definición de la misma:
                     */
                    if(f.arg_table.size() == f.arg_count)
                    {
                        // Ahora evalúa la función:
                        istringstream func(f.body);
                        istream* tmp = input;
                        input = &func;
                        map<string, double>* tmptable = table; /* Asignacion temporal de la tabla,
                                                                  para evitar que se pierda */
                        table = &f.arg_table;
                        it = tmptable->begin();
                        // Copiar variables globales a la tabla de símbolos:
                        while(it != tmptable->end())
                        {
                            table->operator[](it->first) = it->second;
                            ++it;
                        }
                        double value = 0;
                        while(*input) // Mientras existan entrada
                        {
                            get_token();                       // Leemos
                            if(curr_tok == END) break;         // Verificamos si salimos
                            if(curr_tok == PRINT) continue;    // o continuamos
                            value = expr(false);
                        }
                        input = tmp;      // Reasignamos la entrada
                        table = tmptable; // Reasignamos la tabla o mapeo de funciones
                        return value;
                    }
                    else
                    {
                        return error("numero invalido de argumentos");
                    }
                }
                else
                {
                    return error("'(' esperado en llamada de funcion");
                }
            }
            else // Definicion de la funcion
            {
                Function f(string_value);
                if(get_token() == LP)	// Se Obtienen los argumentos
                {
                    while(get_token() != RP && curr_tok != END)
                    {
                        switch(curr_tok)
                        {
                            case NAME:  // El nombre
                                f.arg_table[string_value];
                                break;
                            case COMMA: // El separador
                                continue;
                                break;
                            default:    // Si se llega aca, es porque se produjo un error
                                return error("parametro de funcion invalido");
                        }
                    }
                    f.arg_count = f.arg_table.size();
                    // Se lee el cuerpo de la funcion
                    if(get_token() == LCB)
                    {
                        f.body = string_value;
                    }
                    else
                    {
                        return error("funcion indefinida; definicion faltante");
                    }

                    // Leida la funcion, se guarda en la tabla de símbolos:
                    func_table[f.name] = f;
                    return 0;
                }
                else // Error
                {
                    return error("'(' esperado en la definicion de la funcion");
                }

                return 0;
            }
        }
        case SUB: // Resta
            return -prim(true);
        case LP: // Caso de ausencia de elementos de cierre, como parentesis
        {
            double e = expr(true);
            if(curr_tok != RP)
                return error("')' esperado, pero no encontrado");
            get_token();
            return e;
        }
        default: // En el caso de que no existe el elemento de apertura,
            // estaria por ejemplo: el parentesis de cierre, pero no el de apertura
            return error("primario esperado");
    }
}

/*
 * Verifica si una funcion existe
 */
bool funcExists(const string& name)
{
    return func_table.count(name) ? true : false;
}

#endif //PROYECTO_03_VERSION_FINAL_ESTE_CALCULADORA_H
