#include "calculadora.h"
using namespace std;
/*
 * Funcion  principal, la cual puede recibir argumentos
 */
int main(int argc, char* argv[])
{
    /*
     * Casos en los argumentos pasados a la funcion principal, por linea de comandos.
     * Recuerdese que por linea de comandos, el nombre del ejecutable se considera el
     * primer argumento.
     */
    switch(argc)
    {
        /*
         * Este primer caso, refiere a que no se recibieron argumentos en la linea de
         * comandos, por lo que deben ser leidos luego de la ejecucion del ejecutable
         * del programa, esta es la opcion mas recomendada.
         */
        case 1:
            input = &cin;
            break;

            /*
             * Este caso refiere a que se han pasado argumentos al programa desde la linea
             * de comandos.
             */
        case 2:
        {
            istringstream ss(argv[1]);
            input = &ss;
            break;
        }

            /*
             * Se controla el caso en el que se excedan la cantidad de parametros pasados
             * por lineas de comandos.
             */
        default:
            error("Demasiados argumentos");
            return 1;
    }

    /*
     * Configura la tabla de símbolos para que apunte a los globales. Ambos definidos
     * en el archivo de cabecera .h
     */
    table = &globals;

    /*
     * Se establecen constantes predefinidas, en el caso de requerirse, considerando
     * que es una calculadora.
     */
    table->operator[]("pi") = 3.1415926535897932385;
    table->operator[]("e") = 2.7182818284590452354;

    /*
     * Se realiza la lectura de entradas, el proceso de la calculadora
     */
    while(*input)
    {
        get_token();                    // Leemos un TOKEN, es decir entradas asociadas a la enumeracion
        if(curr_tok == END) break;      // El enum END, termina la ejecucion
        if(curr_tok == PRINT) continue; // El enum PRINT, continua la ejecucion

        /*
         * Mostramos en pantalla
         */
        cout << expr(false) << endl;
    }
    /*
     * *******************************************************************************
     */

    cout << endl; // Mostramos una linea o nueva linea

    return no_of_errors; // Retornamos el error asociado a la ejecucion del programa, en caso de existir
}